package com.vironit.dropit.util;

public interface LinkSources {

    String YOUTUBE_LINK = "https://www.youtube.com";
    String YOUTUBE_SHARE_LINK = "https://youtu.be";
    String SPOTIFY_SHARE_LINK = "https://open.spotify.com";
    String APPLE_MUSIC_LINK = "https://music.apple.com";
}