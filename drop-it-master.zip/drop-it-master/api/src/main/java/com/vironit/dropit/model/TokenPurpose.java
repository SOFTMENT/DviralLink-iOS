package com.vironit.dropit.model;

public enum TokenPurpose {
	REGISTRATION, PASSWORD_RETRIEVING
}
