package com.vironit.dropit.service;

import com.vironit.dropit.model.Post;

public interface LinkService {

	Post formPost(String link);
}