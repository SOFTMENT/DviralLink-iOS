package com.vironit.dropit.dto;

import lombok.Data;

@Data
public class DeviceTokenDto {
    private String token;
}
