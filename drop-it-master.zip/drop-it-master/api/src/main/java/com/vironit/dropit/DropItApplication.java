package com.vironit.dropit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DropItApplication {
    public static void main(String[] args) {
        SpringApplication.run(DropItApplication.class, args);
    }
}