package com.vironit.dropit.model;

public enum AuthenticationProvider {

    GOOGLE, APPLE, LOCAL
}