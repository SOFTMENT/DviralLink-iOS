ALTER TABLE "tokens"
    ADD COLUMN "purpose" varchar(50) NOT NULL;