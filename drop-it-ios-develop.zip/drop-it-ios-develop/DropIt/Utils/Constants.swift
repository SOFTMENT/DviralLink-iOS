//
//  Constants.swift
//  DropIt
//
//
import Moya
import UIKit

struct ApiConstants {
    static let urlBase = "http://ec2-18-156-155-73.eu-central-1.compute.amazonaws.com"
}

struct FirstTimeListenLimit {
    static let timeToWait = 30
}
