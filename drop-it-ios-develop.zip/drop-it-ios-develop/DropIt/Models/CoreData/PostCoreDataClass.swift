//
//  Post+CoreDataClass.swift
//  
//
//
//

import CoreData

public class Post: NSManagedObject {}
