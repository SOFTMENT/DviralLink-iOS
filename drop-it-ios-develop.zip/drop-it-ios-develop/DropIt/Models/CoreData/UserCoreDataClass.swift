//
//  User+CoreDataClass.swift
//  
//
//
//

import CoreData

public class User: NSManagedObject {}
