//
//  UserBookNowTableViewCell.swift
//  DropIt
//
//  Created by Vijay Rathore on 17/10/22.
//

import UIKit

class UserBookNowTableViewCell : UITableViewCell {
    
 
    @IBOutlet weak var mImage: UIImageView!
  
    @IBOutlet weak var mView: UIView!
    
    @IBOutlet weak var mName: UILabel!
    
    
    @IBOutlet weak var mPrice: UILabel!
    
    @IBOutlet weak var bookNowBtn: UIButton!
    override class func awakeFromNib() {
        
    }
    
}
