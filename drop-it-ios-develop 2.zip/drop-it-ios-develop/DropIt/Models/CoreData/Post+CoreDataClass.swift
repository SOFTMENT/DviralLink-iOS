//
//  Post+CoreDataClass.swift
//  
//
//  Created by user on 7/6/21.
//
//

import Foundation
import CoreData


public class Post: NSManagedObject {

}
