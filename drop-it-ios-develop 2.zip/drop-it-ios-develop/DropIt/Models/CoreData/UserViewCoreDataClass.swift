//
//  UserView+CoreDataClass.swift
//  
//
//
//

import CoreData

public class UserView: NSManagedObject {}
