//
//  StudioModel.swift
//  DropIt
//
//  Created by Vijay Rathore on 16/10/22.
//

import UIKit

class StudioModel : NSObject, Codable {
    
    var id : String?
    var name : String?
    var address : String?
    var price : Int?
    var image : String?
    

    
    
}
