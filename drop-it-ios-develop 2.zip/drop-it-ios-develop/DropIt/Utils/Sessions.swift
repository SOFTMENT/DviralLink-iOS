//
//  Session.swift
//  DropIt
//
//

import UIKit

struct Sessions {
    static var token: String = ""
}
